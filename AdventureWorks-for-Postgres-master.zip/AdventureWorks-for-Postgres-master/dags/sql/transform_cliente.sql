-- CARGA DA TABELA DIMCLIENTE

TRUNCATE TABLE dimcliente;

INSERT INTO dimcliente (
    id_cliente,
    id_cliente_origem,
    nome,
    sobrenome,
    email,
    tipo_cliente,
    cidade,
    estado,
    pais
)
SELECT
    ROW_NUMBER() OVER (ORDER BY T1.BusinessEntityID) AS id_cliente,
    T1.BusinessEntityID AS id_cliente_origem,
    T1.FirstName AS nome,
    T1.LastName AS sobrenome,
    T3.EmailAddress AS email,
    CASE
        WHEN T1.PersonType = 'IN' THEN 'Pessoa Física'
        WHEN T1.PersonType = 'SP' THEN 'Vendedor'
        WHEN T1.PersonType = 'EM' THEN 'Empregado'
        ELSE 'Outros'
    END AS tipo_cliente,
    T5.City AS cidade,
    T6.Name AS estado,
    T7.Name AS pais
FROM Person.Person AS T1
INNER JOIN Sales.Customer AS T2 ON T1.BusinessEntityID = T2.PersonID
LEFT JOIN Person.EmailAddress AS T3 ON T1.BusinessEntityID = T3.BusinessEntityID
LEFT JOIN Person.BusinessEntityAddress AS T4 ON T1.BusinessEntityID = T4.BusinessEntityID AND T4.AddressTypeID = 2
LEFT JOIN Person.Address AS T5 ON T4.AddressID = T5.AddressID
LEFT JOIN Person.StateProvince AS T6 ON T5.StateProvinceID = T6.StateProvinceID
LEFT JOIN Person.CountryRegion AS T7 ON T6.CountryRegionCode = T7.CountryRegionCode
WHERE T1.PersonType IN ('IN', 'SP');
