CREATE TABLE IF NOT EXISTS dimcliente (
    id_cliente INT PRIMARY KEY,
    id_cliente_origem INT NOT NULL,
    nome VARCHAR(50),
    sobrenome VARCHAR(50),
    email VARCHAR(100),
    tipo_cliente VARCHAR(30),
    cidade VARCHAR(100),
    estado VARCHAR(100),
    pais VARCHAR(100)
);
