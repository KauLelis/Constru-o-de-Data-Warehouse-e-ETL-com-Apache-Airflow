TRUNCATE TABLE dimproduto;

INSERT INTO dimproduto (
    produto_chave,
    sku_produto,
    nome_produto,
    cor,
    tamanho,
    custo_padrao,
    preco_venda,
    subcategoria_nome,
    categoria_nome
)
SELECT
    p.productid AS produto_chave,
    p.productnumber AS sku_produto,
    p.name AS nome_produto,
    p.color AS cor,
    p.size AS tamanho,
    p.standardcost AS custo_padrao,
    p.listprice AS preco_venda,
    psc.name AS subcategoria_nome,
    pc.name AS categoria_nome
FROM production.product p
LEFT JOIN production.productsubcategory psc 
    ON p.productsubcategoryid = psc.productsubcategoryid
LEFT JOIN production.productcategory pc 
    ON psc.productcategoryid = pc.productcategoryid;
