CREATE TABLE IF NOT EXISTS dimproduto (
    produto_chave INT PRIMARY KEY,
    sku_produto VARCHAR(25) NOT NULL UNIQUE,
    nome_produto VARCHAR(50) NOT NULL,
    cor VARCHAR(15),
    tamanho VARCHAR(5),
    custo_padrao NUMERIC,
    preco_venda NUMERIC,
    subcategoria_nome VARCHAR(50),
    categoria_nome VARCHAR(50)
);
