from airflow import DAG
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.utils.dates import days_ago

# 1. Parâmetros Padrão da DAG
default_args = {
    'owner': 'airflow',
    'start_date': days_ago(1),
    'retries': 1,
}

# 2. Definição da DAG
with DAG(
    dag_id='etl_adventureworks_dw',
    default_args=default_args,
    description='Pipeline ETL para carregar o Data Warehouse AdventureWorks (Star Schema)',
    schedule_interval=None,
    catchup=False,
    tags=['dw', 'etl', 'adventureworks'],
) as dag:
    
    # ============================
    # 3. CRIAÇÃO DAS TABELAS
    # ============================

    create_dim_cliente = PostgresOperator(
        task_id='create_dim_cliente',
        postgres_conn_id='postgres_dw_connection',
        sql='sql/create_dim_cliente.sql'
    )

    create_dim_produto = PostgresOperator(
        task_id='create_dim_produto',
        postgres_conn_id='postgres_dw_connection',
        sql='sql/create_dim_produto.sql'
    )

    # ============================
    # 4. CARGA DAS DIMENSÕES
    # ============================

    load_dim_cliente = PostgresOperator(
        task_id='load_dim_cliente',
        postgres_conn_id='postgres_dw_connection', 
        sql='sql/transform_cliente.sql', 
    )

    load_dim_produto = PostgresOperator(
        task_id='load_dim_produto',
        postgres_conn_id='postgres_dw_connection',
        sql='sql/transform_produto.sql',
    )

    # ============================
    # 5. DEPENDÊNCIAS
    # ============================

    create_dim_cliente >> load_dim_cliente
    create_dim_produto >> load_dim_produto
