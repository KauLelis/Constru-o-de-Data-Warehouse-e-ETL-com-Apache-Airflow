-- DDL SCRIPT PARA O DATA WAREHOUSE (MODELO ESTRELA)
-- Cria 5 Dimensões e 1 Tabela Fato para o esquema FatoVendas

-- ===================================
-- 1. CRIAÇÃO DAS DIMENSÕES
-- ===================================

-- 1.1. Dimensão Data (DimData)
-- Nota Esta tabela deve ser preenchida posteriormente por um script de calendário.
CREATE TABLE DimData (
    id_data INT PRIMARY KEY,
    data DATE NOT NULL UNIQUE,
    dia SMALLINT NOT NULL,
    mes SMALLINT NOT NULL,
    ano SMALLINT NOT NULL,
    trimestre SMALLINT NOT NULL,
    dia_semana SMALLINT NOT NULL
);

-- 1.2. Dimensão Cliente (DimCliente)
CREATE TABLE DimCliente (
    id_cliente INT PRIMARY KEY, -- Chave Substituta (SK)
    id_cliente_origem INT NOT NULL UNIQUE, -- Chave de Negócio (BK) (BusinessEntityID  CustomerID do OLTP)
    nome VARCHAR(100) NOT NULL,
    sobrenome VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    tipo_cliente VARCHAR(50), -- Transformação (ex 'Pessoa Física', 'Pessoa Jurídica')
    cidade VARCHAR(50),
    estado VARCHAR(50),
    pais VARCHAR(50)
);

-- 1.3. Dimensão Produto (DimProduto)
CREATE TABLE DimProduto (
    id_produto INT PRIMARY KEY, -- Chave Substituta (SK)
    id_produto_origem INT NOT NULL UNIQUE, -- Chave de Negócio (BK) (ProductID do OLTP)
    nome VARCHAR(100) NOT NULL,
    subcategoria_nome VARCHAR(50),
    categoria_nome VARCHAR(50),
    tamanho VARCHAR(10),
    peso NUMERIC(8, 2),
    cor VARCHAR(15),
    lista_preco NUMERIC(10, 2)
);

-- 1.4. Dimensão Território (DimTerritorio)
CREATE TABLE DimTerritorio (
    id_territorio INT PRIMARY KEY, -- Chave Substituta (SK)
    id_territorio_origem INT NOT NULL UNIQUE, -- Chave de Negócio (BK) (TerritoryID do OLTP)
    nome_territorio VARCHAR(50) NOT NULL,
    grupo VARCHAR(50),
    pais VARCHAR(50)
);

-- 1.5. Dimensão Método de Envio (DimMetodoEnvio)
CREATE TABLE DimMetodoEnvio (
    id_metodo_envio INT PRIMARY KEY, -- Chave Substituta (SK)
    id_metodo_envio_origem INT NOT NULL UNIQUE, -- Chave de Negócio (BK) (ShipMethodID do OLTP)
    nome VARCHAR(50) NOT NULL,
    custo_base NUMERIC(8, 2)
);

-- ===================================
-- 2. CRIAÇÃO DA TABELA FATO
-- ===================================

-- Tabela Fato Vendas (FatoVendas)
CREATE TABLE FatoVendas (
    -- Chaves Substitutas (Foreign Keys)
    id_cliente INT NOT NULL,
    id_produto INT NOT NULL,
    id_data INT NOT NULL,
    id_territorio INT NOT NULL,
    id_metodo_envio INT NOT NULL,

    -- Métricas  Colunas Fato
    quantidade INT NOT NULL,
    preco_unitario NUMERIC(10, 2) NOT NULL,
    desconto NUMERIC(10, 2) NOT NULL,
    valor_liquido NUMERIC(10, 2) NOT NULL, -- (quantidade  preco_unitario) - desconto
    total_venda NUMERIC(10, 2) NOT NULL, -- Valor Líquido + impostosfrete (se aplicável, dependendo da fonte)
    
    -- Chave Composta  Primary Key (Geralmente opcional para tabelas Fato grandes)
    PRIMARY KEY (id_cliente, id_produto, id_data, id_territorio, id_metodo_envio),

    -- Definição das Chaves Estrangeiras (FKs)
    FOREIGN KEY (id_cliente) REFERENCES DimCliente (id_cliente),
    FOREIGN KEY (id_produto) REFERENCES DimProduto (id_produto),
    FOREIGN KEY (id_data) REFERENCES DimData (id_data),
    FOREIGN KEY (id_territorio) REFERENCES DimTerritorio (id_territorio),
    FOREIGN KEY (id_metodo_envio) REFERENCES DimMetodoEnvio (id_metodo_envio),

    -- Constraints para garantir a integridade das métricas (opcional, mas bom)
    CONSTRAINT CK_FatoVendas_Quantidade CHECK (quantidade > 0),
    CONSTRAINT CK_FatoVendas_PrecoUnitario CHECK (preco_unitario = 0.00)
);